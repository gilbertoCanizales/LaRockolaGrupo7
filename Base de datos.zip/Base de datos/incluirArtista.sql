INSERT INTO larockola.artista(artista.nombre, artista.nacionalidad) values ("Edith Piaf", "Francia");
delete FROM larockola.artista where idArtistas=15;