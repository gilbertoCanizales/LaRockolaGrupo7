INSERT INTO larockola.listareproduccion(listareproduccion.idUsuario, listareproduccion.fechaUltimaReproduccion, listareproduccion.listaFavorita, listareproduccion.nombreLista) 
values ( "7", "2021-08-31", "N", "Usuario6Lista2 Folk");
