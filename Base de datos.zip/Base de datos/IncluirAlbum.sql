INSERT INTO larockola.album(album.nombre, album.year, album.idArtistaAlbum ) values ("A Night at the Opera ",1975, 8);
delete FROM larockola.album where idAlbum= 7;